#!/bin/bash

#####   vorher  -->  play build-module  <-- aufrufen

PROJEKT=`pwd | rev | cut -d "/" -f 1 | rev`
echo $PROJEKT

if [ "x$1" = "x--go" ]; then
	echo "Kopiere alle Dateien aus dist/ nach playmodules.teuto.net"
else 
	while true; do
		read -p  "Modul neu bauen? [J]n] " yn
		if [ "x$yn" = "x" ]; then
			yn="j"
		fi
		case $yn in
			[Nn]* ) echo "Modul nicht neu gebaut"
					break
					;;
			[JjYy]) 
					echo "Baue Modul neu"
					DEP=conf/dependencies.yml
					DEPBAK=conf/dependencies.yml.bak
					MAJOR=`grep $PROJEKT conf/dependencies.yml | cut  -d ' ' -f 5 | cut -d '.' -f 1`
					SUB=`grep $PROJEKT conf/dependencies.yml | cut  -d ' ' -f 5 | cut -d '.' -f 2`
					MINOR=`grep $PROJEKT conf/dependencies.yml | cut  -d ' ' -f 5 | cut -d '.' -f 3`
					echo $MINOR
					declare i MINOR=$((MINOR+1))
					sed  -e "s/$PROJEKT\s\s*\(.*\)*/$PROJEKT $MAJOR.$SUB.$MINOR/" $DEP > $DEPBAK
					mv $DEPBAK $DEP
					play build-module 
					break
					;;
			*)      echo "[$yn]"    
		esac
	done
	while true; do
		read -p  "Sollen alle Dateien aus dist/ nach playmodules.teuto.net kopiert werden? [J]n] " yn
		if [ "x$yn" = "x" ]; then
			yn="j"
		fi
		case $yn in 
			[Nn]* ) echo "Dann eben nicht."
					exit 1
					;;
			[JjYy]) 
					echo "OK"
					break
					;;
			*)      echo "[$yn]"    
		esac
	done
fi
		
scp dist/* root@devel.teuto.net:/home/playmodules.teuto.net/docs/mod/

