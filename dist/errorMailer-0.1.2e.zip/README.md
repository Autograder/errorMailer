errorMailer
===========

Play! One module. Sends you an email with detailed information to any exception raised in a controller or a template and includes information about the request, params, cookies, the renderArgs, ...

This module has a simple 3 step integration process. For details please have a look at http://www.playmodules.net/module/21
