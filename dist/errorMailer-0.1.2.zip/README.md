errorMailer
===========

Play! One module. Sends you an email with detailed information to any exception raised in a controller or a template and includes information about the request, params, cookies, the renderArgs, ...